﻿namespace CustomStack
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            StackOfStrings stack = new StackOfStrings("Gosho");

            stack.AddRange();
            Console.WriteLine(string.Join(" ", stack));
        }
    }
}
