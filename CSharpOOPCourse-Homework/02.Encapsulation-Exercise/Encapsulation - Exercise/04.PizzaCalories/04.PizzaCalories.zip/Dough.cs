﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaCalories
{
    public class Dough
    {
        private const double CaloriesPerGram = 2;

        private string flourType;
        private string bakingTechnique;
        private double doughWeight;
        private double flourTypeCalories;
        private double bakingTechniqueCalories;

        public Dough(string flourType, string bakingTechnique, double doughWeight)
        {
            this.FlourType = flourType;
            this.BakingTechnique = bakingTechnique;
            this.DoughWeight = doughWeight;
        }

        public double TotalCalories => CalculateCaloriesPerGram();

        public string FlourType
        {
            get => this.flourType;
            private set
            {
                value = value.ToString().ToLower();

                if (value != "white" && value != "wholegrain")
                {
                    throw new ArgumentException("Invalid type of dough.");
                }

                value = string.Concat(value[0].ToString().ToUpper(), value.AsSpan(1));
                this.flourType = value;
            }
        }

        public string BakingTechnique
        {
            get => this.bakingTechnique;
            private set
            {
                value = value.ToString().ToLower();

                if (value != "crispy" && value != "chewy" && value != "homemade")
                {
                    throw new ArgumentException("Invalid type of dough.");
                }

                value = string.Concat(value[0].ToString().ToUpper(), value.AsSpan(1));
                this.bakingTechnique = value;
            }
        }

        public double DoughWeight
        {
            get => this.doughWeight;
            private set
            {
                if (value < 1 || value > 200)
                {
                    throw new ArgumentException("Dough weight should be in the range [1..200].");
                }

                this.doughWeight = value;
            }
        }

        private double CalculateCaloriesPerGram()
        {
            switch (this.FlourType)
            {
                case "White":
                    this.flourTypeCalories = 1.5;
                    break;
                case "Wholegrain":
                    this.flourTypeCalories = 1.0;
                    break;
            }

            switch (this.BakingTechnique)
            {
                case "Crispy":
                    this.bakingTechniqueCalories = 0.9;
                    break;
                case "Chewy":
                    this.bakingTechniqueCalories = 1.1;
                    break;
                case "Homemade":
                    this.bakingTechniqueCalories = 1.0;
                    break;
            }

            return CaloriesPerGram * this.DoughWeight * this.flourTypeCalories * this.bakingTechniqueCalories;
        }
    }
}