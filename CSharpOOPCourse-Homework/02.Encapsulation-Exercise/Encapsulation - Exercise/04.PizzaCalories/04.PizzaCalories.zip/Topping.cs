﻿/*
Pizza 
Dough White Chewy 100
Topping Sauce 20
Topping Cheese 50
Topping Cheese 40
Topping Meat 10
Topping Sauce 10
Topping Cheese 30
Topping Cheese 40
Topping Meat 20
Topping Sauce 30
Topping Cheese 25
Topping Cheese 40
Topping Meat 40
END
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaCalories
{
    public class Topping
    {
        private const double CaloriesPerGram = 2;

        private string type;
        private double weight;
        private double typeCalories;

        public Topping(string type, double weight)
        {
            this.Type = type;
            this.Weight = weight;
        }

        public string Type
        {
            get => this.type;
            private set
            {
                value = value.ToString().ToLower();

                if (value != "meat" && value != "cheese" && value != "veggies" && value != "sauce")
                {
                    value = string.Concat(value[0].ToString().ToUpper(), value.AsSpan(1));
                    throw new ArgumentException($"Cannot place {value} on top of your pizza.");
                }

                value = string.Concat(value[0].ToString().ToUpper(), value.AsSpan(1));
                this.type = value;
            }
        }

        public double Weight
        {
            get => this.weight;
            private set
            {
                if (value < 1 || value > 50)
                {
                    throw new ArgumentException($"{this.Type} weight should be in the range [1..50].");
                }

                this.weight = value;
            }
        }

        public double TotalCalories => CalculateCaloriesPerGram();

        private double CalculateCaloriesPerGram()
        {
            switch (this.Type)
            {
                case "Meat":
                    this.typeCalories = 1.2;
                    break;
                case "Veggies":
                    this.typeCalories = 0.8;
                    break;
                case "Cheese":
                    this.typeCalories = 1.1;
                    break;
                case "Sauce":
                    this.typeCalories = 0.9;
                    break;
            }

            return (CaloriesPerGram * this.Weight) * this.typeCalories;
        }
    }
}