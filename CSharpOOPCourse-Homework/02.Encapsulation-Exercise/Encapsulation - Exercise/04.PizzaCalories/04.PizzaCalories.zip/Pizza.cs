﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaCalories
{
    public class Pizza
    {
        private string name;
        private Dough dough;
        private List<Topping> toppings;
        private int numberOfToppings;

        public Pizza(string name)
        {
            this.Name = name;
            this.toppings = new List<Topping>();
        }

        public string Name
        {
            get => this.name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value) || value.Length > 15)
                {
                    throw new ArgumentException("Pizza name should be between 1 and 15 symbols.");
                }

                this.name = value;
            }
        }

        public Dough Dough
        {
            get => this.dough;
            set
            {
                this.dough = value;
            }
        }

        public int NumberOfToppings
        {
            get => this.numberOfToppings;
            private set
            {
                if (this.numberOfToppings > 10)
                {
                    throw new ArgumentException("Number of toppings should be in range [0..10].");
                }

                this.numberOfToppings = value;
            }
        }

        public double TotalCalories => CalculateTotalCalories();

        public IReadOnlyCollection<Topping> Toppings => this.toppings;

        private double CalculateTotalCalories()
        {
            //double totalCalories = 0;
            //totalCalories += this.dough.TotalCalories;

            //foreach (var topping in this.toppings)
            //{
            //    totalCalories += topping.TotalCalories;
            //}

            return this.dough.TotalCalories + this.toppings.Sum(x => x.TotalCalories);
        }

        public void AddTopping(Topping topping)
        {
            this.NumberOfToppings++; 
            this.toppings.Add(topping);
        }

        public override string ToString()
        {
            return $"{this.Name} - {this.TotalCalories:F2} Calories.";
        }
    }
}