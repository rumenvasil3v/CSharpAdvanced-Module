﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace _01.ClassBoxData
{
    public class Box
    {
        private double length;
        private double width;
        private double height;

        public Box(double length, double width, double height)
        {
            this.Length = length;
            this.Width = width;
            this.Height = height;
        }

        public double Length
        {
            get => this.length;
            private set
            {
                //PropertyInfo length = typeof(Box).GetProperty(nameof(this.Length)); -> length.Name

                if (value <= 0)
                {
                    throw new ArgumentException($"{nameof(this.Length)} cannot be zero or negative.");
                }

                this.length = value;
            }
        }

        public double Width
        {
            get => this.width;
            private set
            {
                //PropertyInfo width = typeof(Box).GetProperty(nameof(this.Width)); -> width.Name

                if (value <= 0)
                {
                    throw new ArgumentException($"{nameof(this.Width)} cannot be zero or negative.");
                }

                this.width = value;
            }
        }

        public double Height
        {
            get => this.height;
            private set
            {
                //PropertyInfo height = typeof(Box).GetProperty(nameof(this.Height)); -> height.Name

                if (value <= 0)
                {
                    throw new ArgumentException($"{nameof(this.Height)} cannot be zero or negative.");
                }

                this.height = value;
            }
        }

        public double SurfaceArea()
        {
            return 2 * (this.Length * this.Width + this.Length * this.Height + this.Width * this.Height); // Surface Area -> 2lw + 2lh + 2wh
        }

        public double LateralSurfaceArea()
        {
            return 2 * (this.Length * this.Height + this.Width * this.Height); // Lateral Surface Area -> 2lh + 2wh
        }

        public double Volume()
        {
            return this.Length * this.Width * this.Height; // Volume -> l * w * h
        } 
    }
}