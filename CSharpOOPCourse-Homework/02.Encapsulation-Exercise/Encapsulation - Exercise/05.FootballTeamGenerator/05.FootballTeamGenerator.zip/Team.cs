﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballTeamGenerator
{
    public class Team
    {
        private Dictionary<string, Player> players;
        private string name;

        public Team(string name)
        {
            this.Name = name;
            this.players = new Dictionary<string, Player>();
        }

        public string Name
        {
            get => this.name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("A name should not be empty.");
                }

                this.name = value;
            }
        }

        public double Rating => CalculateRatingOfTheTeam();

        public void AddPlayer(Player player)
        {
            this.players.Add(player.Name, player);
        }

        public void RemovePlayer(string playerName)
        {
            if (!this.players.ContainsKey(playerName))
            {
                throw new ArgumentException($"Player {playerName} is not in {this.Name} team.");
            }

            this.players.Remove(playerName);
        }

        private double CalculateRatingOfTheTeam()
        {
            double averageSkillOfAllPlayers = 0;
            foreach (var player in this.players)
            {
                averageSkillOfAllPlayers += (player.Value.Shooting + player.Value.Passing + player.Value.Dribble + player.Value.Sprint + player.Value.Endurance) / 5.0;
            }

            return Math.Round(averageSkillOfAllPlayers);
        }

        public override string ToString()
        {
            return $"{this.Name} - {this.Rating}";
        }
    }
}