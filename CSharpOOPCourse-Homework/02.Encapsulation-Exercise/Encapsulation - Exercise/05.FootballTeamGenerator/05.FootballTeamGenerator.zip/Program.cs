﻿/*
Team;Arsenal
Add;Arsenal;Kieran_Gibbs;75;85;84;92;67
Add;Arsenal;Aaron_Ramsey;195;82;82;89;68
Add;Liverpool;Aaron_Ramsey;195;82;82;89;68
Remove;Arsenal;Aaron_Ramsey
Remove;Arsenal;Kieran_Gibbs
Rating;Arsenal
Rating;Barcelona
END
 */
using FootballTeamGenerator;

Dictionary<string, Team> teams = new();

string command;
while ((command = Console.ReadLine()) != "END")
{
    string[] commandArguments = command.Split(";", StringSplitOptions.RemoveEmptyEntries);
    try
    {
        switch (commandArguments[0])
        {
            case "Add":
                string currentTeamName = commandArguments[1];
                string currentPlayerName = commandArguments[2];
                int playerEndurance = int.Parse(commandArguments[3]);
                int playerSprint = int.Parse(commandArguments[4]);
                int playerDribble = int.Parse(commandArguments[5]);
                int playerPassing = int.Parse(commandArguments[6]);
                int playerShooting = int.Parse(commandArguments[7]);

                if (teams.ContainsKey(currentTeamName))
                {
                    Player player = new(currentPlayerName, playerEndurance, playerSprint, playerDribble, playerPassing, playerShooting);

                    teams[currentTeamName].AddPlayer(player);
                }
                else
                {
                    throw new ArgumentException($"Team {currentTeamName} does not exist.");
                }
                break;
            case "Remove":
                string removePlayerFromTeamName = commandArguments[1];
                string removePlayer = commandArguments[2];

                teams[removePlayerFromTeamName].RemovePlayer(removePlayer);
                break;
            case "Team":
                string teamName = commandArguments[1];
                Team team = new Team(teamName);

                teams.Add(teamName, team);
                break;
            case "Rating":
                string ratingCurrentTeam = commandArguments[1];

                if (teams.ContainsKey(ratingCurrentTeam))
                {
                    Console.WriteLine(teams[ratingCurrentTeam].ToString());
                }
                else
                {
                    throw new ArgumentException($"Team {ratingCurrentTeam} does not exist.");
                }
                break;
        }
    }
    catch (ArgumentException ex)
    {
        Console.WriteLine(ex.Message);
    }
}