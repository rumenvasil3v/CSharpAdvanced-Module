﻿/*
4
DSL-10 280 B
V7-55 200 35
DSL-13 305 55 A+
V7-54 190 30 D
4
FordMondeo DSL-13 Purple
VolkswagenPolo V7-54 1200 Yellow
VolkswagenPassat DSL-10 1375 Blue
FordFusion DSL-13
 */

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Engine> engines = new List<Engine>();

            int numberOfEngines = int.Parse(Console.ReadLine());
            for (int n = 0; n < numberOfEngines; n++)
            {
                string[] engineInfo = Console
                    .ReadLine()
                    .Split(' ');

                string engineModel = engineInfo[0];
                int enginePower = int.Parse(engineInfo[1]);

                string engineEfficiency = string.Empty;
                if (engineInfo.Length > 2)
                {
                    bool isItTrue = int.TryParse(engineInfo[2], out int engineDisplacement);
                    if (isItTrue)
                    {
                        if (engineInfo.Length > 3)
                        {
                            engineEfficiency = engineInfo[3];
                        }
                    }
                    else
                    {
                        engineEfficiency = engineInfo[2];
                    }

                    Engine engine = new Engine(engineModel, enginePower, engineDisplacement, engineEfficiency);

                    engines.Add(engine);
                }
                else
                {
                    Engine engine = new Engine(engineModel, enginePower, 0, string.Empty);

                    engines.Add(engine);
                }
            }

            List<Car> cars = new List<Car>();

            int numberOfCars = int.Parse(Console.ReadLine());
            for (int n = 0; n < numberOfCars; n++)
            {
                string[] carInfo = Console
                    .ReadLine()
                    .Split(' ');

                string carModel = carInfo[0];

                string carEngine = carInfo[1];
                Engine engine = engines.FirstOrDefault(e => e.Model == carEngine);

                string carColor = string.Empty;
                if (carInfo.Length > 2)
                {
                    bool isIsTrue = int.TryParse(carInfo[2], out int carWeight);
                    if (isIsTrue)
                    {
                        if (carInfo.Length > 3)
                        {
                            carColor = carInfo[3];
                        }
                    }
                    else
                    {
                        carColor = carInfo[2];
                    }

                    Car car = new Car(carModel, engine, carWeight, carColor);
                    cars.Add(car);
                }
                else
                {
                    Car car = new Car(carModel, engine, 0, string.Empty);
                    cars.Add(car);
                }
            }

            foreach (Car car in cars)
            {
                Console.WriteLine($"{car.Model}:");
                Console.WriteLine($"  {car.Engine.Model}:");
                Console.WriteLine($"    Power: {car.Engine.Power}");

                if (car.Engine.Displacement == 0)
                {
                    Console.WriteLine(@"    Displacement: n/a");
                }
                else
                {
                    Console.WriteLine($"    Displacement: {car.Engine.Displacement}");
                }

                if (car.Engine.Efficiency == string.Empty)
                {
                    Console.WriteLine(@"    Efficiency: n/a");
                }
                else
                {
                    Console.WriteLine($"    Efficiency: {car.Engine.Efficiency}");
                }

                if (car.Weight == 0)
                {
                    Console.WriteLine(@"  Weight: n/a");
                }
                else
                {
                    Console.WriteLine($"  Weight: {car.Weight}");
                }

                if (car.Color == string.Empty)
                {
                    Console.WriteLine(@"  Color: n/a");
                }
                else
                {
                    Console.WriteLine($"  Color: {car.Color}");
                }
            }
        }
    }
}